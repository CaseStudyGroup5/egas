    import React, { Component } from 'react';
    import AdminService from '../services/AdminService';

    class ListDealerComponent extends Component {
        constructor(props) {
            super(props)

            this.state = {
                dealers: []
            //    data:
            //     {
            //       dealerId: "",
            //       dealerStatus: ""
            //     }
            // }
        
            }
        }

      
        // componentDidMount() {
        //     AdminService.getDealers().then((res) => {
        //         console.log('ressssss',res)
        //         this.setState({ dealers: res.data });
        //     });
        // }
           
        // approveDealer(ename)
        // {
        //   var status="Approved"
        
        //  this.setState(prevState => ({
        //   data: {                   // object that we want to update
        //                           // keep all other key-value pairs
        //       dealerId: ename,      // update the value of specific key
        //       dealerStatus:status
        //   }
         
        // }))
//         console.log(this.state.data);
// AdminService.updatedealerStatus(this.state.data);
// }

//   disapproveDealer(ename)
// {

//   var status="DisApproved"
//   this.setState(prevState => ({
//     data: {                   // object that we want to update
//                             // keep all other key-value pairs
//        dealerId: ename,      // update the value of specific key
//         dealerStatus:status
//     }
// }))
// console.log(this.state.data);
// AdminService.updatedealerStatus(this.state.data);
// }
       

        
        render() {

            return (
                <div style={{margin:'2%'}}>
                    <h2 className="text-center">Dealer List</h2>
                    
                        <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                               <th>pancardNumber</th>
                                <th>firstName</th>
                                <th>lastName</th>
                                <th>gender</th>
                                <th>email</th>
                                <th>contactNumber</th>
                                <th>password</th>
                                <th>city</th>
                                <th>state</th>
                                <th>Dealer Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.dealers.map(
                                    dealer =>
                                        <tr key={dealer.dealerId}>
                                             <td>{dealer.pancardNumber}</td>
                                            <td>{dealer.firstName}</td>
                                            <td>{dealer.lastName}</td>
                                            <td>{dealer.gender}</td>
                                            <td>{dealer.email}</td>
                                            <td>{dealer.contactNumber}</td>
                                            <td>{dealer.password}</td>
                                            <td>{dealer.city}</td>
                                            <td>{dealer.state}</td>
                                            <td>
                                            
                                           
             <button type="button" class="btn btn-success " onClick={ () => this.approveDealer(dealer.dealerId)}>Approve</button>
             <span className="spacing"><button type="button" class="btn btn-danger" onClick={ () => this.disapproveDealer(dealer.dealerId)}>DisApprove</button></span>
             
                                            
                                            </td>
                                        </tr>
                                )
                            }

                        </tbody>
                    </table>


                </div>
            );
        }
    }

    export default ListDealerComponent;