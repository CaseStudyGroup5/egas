import React from 'react'
import 'bootstrap/dist/css/bootstrap.css'

function AdminComponent() {
    return (
        <div>
          <h2>Admin Page </h2>
        </div>

    )
}

export default AdminComponent