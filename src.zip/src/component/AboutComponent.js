import React from 'react'

function AboutComponent() {
    return (
        <div className="container mt-2">
            <h2>About EGas</h2>
        </div>
    )
}

export default AboutComponent