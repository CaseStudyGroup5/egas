import React from 'react'

function StaffComponent() {
    return (
        <div className="container mt-2">
            <h2>Staff Delivery Module</h2>
            <a href="/staffreg">Registration</a>
        </div>
    )
}

export default StaffComponent